import java.util.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class Booking {
    Scanner scanner = new Scanner(System.in);

    private String name;
    private Date date;
    private String movieName;
    private int seats;
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");

    boolean theatreAvailable,movieAvailable;


    String showTime;


    public Booking(ArrayList<Theatre> theatres, ArrayList<Booking> bookings) {
        System.out.println("Enter Theatre name: ");
        name = scanner.nextLine();
        System.out.println("Movie Name: ");
        movieName=scanner.nextLine();
        System.out.println("Enter date dd-mm-yyyy: ");
        String dateInput = scanner.next();
        System.out.println("Enter showTime:");
        showTime=showTiming();
        System.out.println("No.of Seats: ");
        seats=scanner.nextInt();
        try {
            date = dateFormat.parse(dateInput);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if(isAvailable(bookings,theatres)) {
            //bookings.add(new Booking(name,movieName,date,showTime,seats));
            System.out.println("Your booking is confirmed");
        }
        else {
            if (!theatreAvailable)
                System.out.println("This theatre doesn't Exists!! Check Theatre");
            else if (!movieAvailable)
                System.out.println("This movie is not running in that Theatre!! Check another Theatre");
            else
                System.out.println("Sorry. Houseful. Try another Theatre or date.");
        }
    }

    private String showTiming() {
        System.out.println("1.Morning show \n2.Matinee Show \n3.1st Show \n4.2nd Show");
        byte ch= scanner.nextByte();
        switch(ch){
            case 1: return "morning show";
            case 2: return "matinee show";
            case 3: return "1st show";
            case 4: return "2nd show";
        }
        return "";
    }

    private Booking(String name, String movieName, Date date, String showTime, int seats) {
        this.date=date;
        this.seats=seats;
        this.movieName=movieName;
        this.name=name;
        this.showTime=showTime;
    }

    public boolean isAvailable(ArrayList<Booking> bookings, ArrayList<Theatre> theatres) {
        theatreAvailable=false;
        movieAvailable=false;
        int capacity = -1;
        System.out.println(theatres.size());
        for(Theatre theatre:theatres) {
            if(theatre.getTheatreName().equalsIgnoreCase(name)) {
                theatreAvailable = true;
                if (theatre.isMovieAvailable(movieName)) {
                    movieAvailable = true;
                    capacity = theatre.getCapacity();
                }
            }
        }
        int booked = 0;

        for(Booking b:bookings) {
            if(b.name.equalsIgnoreCase(name)) {
                if (b.movieName.equalsIgnoreCase(movieName)) {
                    if (b.date.equals(date)){
                        if(b.showTime.equalsIgnoreCase(showTime))
                            booked += b.noOfSeats();
                    }

                }
            }
        }
        System.out.println(capacity);
        return booked<capacity?true:false;

    }

    private int noOfSeats() {
        return seats;
    }


    public void show() {
        String dateStr = dateFormat.format(date);

        System.out.println(String.format("|%23s|%21s|%11s|%16d|%19s|",name,movieName,dateStr,seats,showTime));
    }
}