import java.util.ArrayList;
import java.util.Scanner;

public class User {
    private String userName;
    private String password;
    private String emailID;

    static Scanner scanner=new Scanner(System.in);
    User(String emailID, String userName, String password){
        this.emailID=emailID;
        this.userName=userName;
        this.password=password;
    }

    public User() {

    }


    public void newRegister(ArrayList<User> users) {
        String confirmPassword;
        System.out.println("Enter emailID: ");
        emailID=scanner.next();
        if((emailID.contains(".com")||emailID.contains(".edu.in")||emailID.contains(".org"))
                && emailID.contains("@") && emailID.indexOf('@')<emailID.lastIndexOf(".")) {
            System.out.println("Enter UserName: ");
            userName = scanner.next();
            System.out.println("Enter password:");
            password = scanner.next();
            System.out.println("Re-Enter password: ");
            confirmPassword = scanner.next();
            if (password.equals(confirmPassword)) {
                users.add(new User(emailID, userName, password));
                System.out.println("Created Account Successfully");
            } else {
                System.out.println("Passwords Are Not Matching!!");
            }
        }
        else
            System.out.println("Invalid EmailID try Again!!");
    }

    public boolean userVerify(String userName, String password){
        return (this.userName.equals(userName) && this.password.equals(password));

    }

    public boolean login(ArrayList<User> users) {
        System.out.println("Enter UserName: ");
        userName=scanner.next();
        System.out.println("Enter password");
        password=scanner.next();
        for(User u:users){
            if(u.userVerify(userName,password))
                return true;
        }
        return false;
    }

    public void addUsers(ArrayList<User> users) {
        users.add(new User("avs@gmail.com","avs","123"));
        users.add(new User("svs@gmail.com","svs","123"));

    }
}
