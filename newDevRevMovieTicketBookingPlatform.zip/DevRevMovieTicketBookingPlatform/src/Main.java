import com.sun.security.jgss.GSSUtil;

import java.util.Scanner; //nested package/ hierarchical package
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        ArrayList<Theatre> theatres = new ArrayList<Theatre>();
        ArrayList<Booking> bookings = new ArrayList<Booking>();
        ArrayList<User> users=new ArrayList<User>();
        User user=new User();
        Admin admin=new Admin();
        int choice;
        admin.addTheatres(theatres);
        user.addUsers(users);
        admin.addMovies(theatres);
        Welcome.message();

        while(true){
            System.out.println("1.Login\t2.Register");
            System.out.print("Enter your choice: ");
            choice=scanner.nextInt();
            //-----LOGIN-----
            if(choice==1){
                System.out.println("1.User Login   2.Admin Login");
                System.out.print("Enter your choice: ");
                choice=scanner.nextInt();
                //------USER LOGIN-----
                if(choice==1){
                    if(user.login(users)){
                        int userOpt = 1;
                        for(Theatre t:theatres) {
                            t.displayBusInfo();
                        }
                        while(true) {
                            System.out.println("Enter 1 to Book and 2 to exit");
                            userOpt = scanner.nextInt();
                            if(userOpt == 1) {
                                bookings.add(new Booking(theatres,bookings));
                            }else if(userOpt==2){
                                break;
                            }
                        }
                    }
                    else{
                        System.out.println("UserName/Password is invalid!! Try Again.");
                    }

                //------ADMIN LOGIN------
                } else if (choice==2) {
                    if(admin.verify()){
                        while(true) {
                            choice = admin.choices();
                            // "1. Add a Theatre \n2. Add a movie \n3.Show Bookings \n4.exit");
                            if (choice == 1) {
                                admin.newTheatre(theatres);
                            } else if (choice == 2) {
                                admin.newMovie(theatres);
                            } else if (choice==3) {
                                admin.showBookings(bookings);
                            } else if(choice==4){
                                break;
                            }else{
                                System.out.println("Invalid Choice!!");
                            }
                        }
                    }else{
                        System.out.println("Invalid Username/Password");
                    }
                }
                //-----REGISTER-----
            } else if (choice==2) {
                user.newRegister(users);
            }
        }

    }

}