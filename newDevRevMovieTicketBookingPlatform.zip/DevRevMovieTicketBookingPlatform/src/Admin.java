import java.util.ArrayList;
import java.util.Scanner;

public class Admin {

    Scanner scanner=new Scanner(System.in);
    private String userName="admin";
    private String password="admin123";
    private int theatreNumber;
    private String theatreName;
    private int capacity;
    private String movieName;
    public boolean verify() {
        String userName,password;
        System.out.println("Enter admin ID:");
        userName=scanner.next();
        System.out.println("Enter admin Password:");
        password=scanner.next();
        return (this.userName.equals(userName) && this.password.equals(password));
    }

    public void newTheatre(ArrayList<Theatre> theatres) {
        System.out.println("Enter Theatre Number: ");
        theatreNumber = scanner.nextInt();
        System.out.println("Enter Theatre Name: ");
        theatreName = scanner.next();
        System.out.println("Capacity: ");
        capacity = scanner.nextInt();
        theatres.add(new Theatre(theatreNumber, theatreName, capacity));
    }

    public void newMovie(ArrayList<Theatre> theatres) {
        System.out.println("Enter Theatre Number: ");
        theatreNumber = scanner.nextInt();
        System.out.println("Enter Movie Name: ");
        movieName = scanner.next();
        boolean theatreExist=false;
        for (Theatre theatre : theatres) {
            if (theatre.getTheatreNumber() == theatreNumber) {
                theatre.addMovies(movieName);
                theatreExist=true;
            }
        }
        if(!theatreExist)
            System.out.println("Theatre doesn't exists.");
    }

    public void addTheatres(ArrayList<Theatre> theatres) {
        theatres.add(new Theatre(1,"MadrasTalkies",2));
        theatres.add(new Theatre(2,"iDreams",50));
        theatres.add(new Theatre(3,"PhoenixFilmCity",60));
    }

    public int choices() {
        System.out.println("1. Add a Theatre \n2. Add a movie \n3.Show Bookings \n4.exit");
        return scanner.nextInt();
    }

    public void showBookings(ArrayList<Booking> bookings) {
        System.out.println(bookings.size());
        System.out.println("+-----------------------+---------------------+-----------+----------------+-------------------+");
        System.out.println("|      Theatre Name     |      Movie Name     |    Date   |      Seats     |    showTime       |");
        System.out.println("+-----------------------+---------------------+-----------+----------------+-------------------+");
        for(Booking booking:bookings){
            booking.show();
            System.out.println("+-----------------------+---------------------+-----------+----------------+-------------------+");

        }

    }

    public void addMovies(ArrayList<Theatre> theatres) {
        for(Theatre theatre:theatres){
            theatre.addMovies("StuartLittle");
            theatre.addMovies("Newton");
        }
    }
}
