# Cinema-Ticket-Reservation-System

This is my term project for my course Object-Oriented Programming. I had made a cinema ticket reservation system using JAVA.

Our goal was on using separate classes and having a clear idea of which class is used why. 

# Admin Login Details
Admin Id: admin

Admin Password: 123

# Existing User Login Details
* e-mailID: avs@gmail.com"

  UserName: "avs"

  Password: "123"

* e-mailID: svs@gmail.com"

  UserName: "svs"

  Password: "123"
