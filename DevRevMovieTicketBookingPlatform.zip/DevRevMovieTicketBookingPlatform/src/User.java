import java.util.ArrayList;

public class User {
    private String userName;
    private String password;
    private String emailID;

    User(String emailID, String userName, String password){
        this.emailID=emailID;
        this.userName=userName;
        this.password=password;
    }

    public boolean userVerify(String userName, String password){
        return (this.userName.equals(userName) && this.password.equals(password));

    }
}
