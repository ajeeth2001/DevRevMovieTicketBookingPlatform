import java.util.ArrayList;

public class Admin {

    private String userName="admin";
    private String password="admin123";
    public boolean verify(String userName, String password) {
        return (this.userName.equals(userName) && this.password.equals(password));
    }
}
