public class Welcome {
    public static void message() {
        System.out.println("-------------------------------------------------------------");
        System.out.println("-------WELCOME TO DEVREV MOVIE TICKET BOOKING PLATFORM-------");
        System.out.println("-------------------------------------------------------------");
        System.out.println();

    }
}
