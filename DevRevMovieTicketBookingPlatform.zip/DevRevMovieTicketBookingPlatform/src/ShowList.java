import java.util.ArrayList;

public class ShowList {
    ArrayList<Theatre> theatre=new ArrayList<>();

}
