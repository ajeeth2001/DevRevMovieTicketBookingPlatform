import java.util.ArrayList;

public class Theatre {
    private String theatreName;
    private int theatreNumber;
    private int capacity;

    private ArrayList<String> movies=new ArrayList<>();

    Theatre(){

    }

    public Theatre(int theatreNumber, String theatreName, int capacity) {
        this.theatreNumber=theatreNumber;
        this.theatreName=theatreName;
        this.capacity=capacity;

    }
    public void addMovies(String name){
        movies.add(name);
    }

    public void displayBusInfo() {
        System.out.println("Theatre Number:"+theatreNumber+" Theatre Name:"+theatreName+" Theatre Capacity:"+capacity);
        System.out.println("Movies Running: ");
        if(movies.size()==0){
            System.out.println("NO MOVIES ARE RUNNING");
        }
        for(String movie:movies){
            System.out.println(movie);
        }
    }


    public int getCapacity() {
        return capacity;
    }

    public int getTheatreNumber() {
        return theatreNumber;
    }

    public String getTheatreName() {
        return theatreName;
    }
}
