import com.sun.security.jgss.GSSUtil;

import java.util.Scanner; //nested package/ hierarchical package
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        ArrayList<Theatre> theatres = new ArrayList<Theatre>();
        ArrayList<Booking> bookings = new ArrayList<Booking>();
        ArrayList<User> users=new ArrayList<User>();
        Admin admin=new Admin();
        int choice;
        boolean loginSuccess=false;
        String emailID;
        String userName;
        String password;
        String theatreName;
        int theatreNumber;
        int capacity;
        String movieName;

        Welcome.message();
        theatres.add(new Theatre(1,"Madras Talkies",2));
        theatres.add(new Theatre(2,"iDreams",50));
        theatres.add(new Theatre(3,"Phoenix Film City",60));
        while(true){
            System.out.println("1.Login\t2.Register");
            System.out.print("Enter your choice: ");
            choice=scanner.nextInt();

            if(choice==1){
                System.out.println("1.User Login   2.Admin Login");
                System.out.print("Enter your choice: ");
                choice=scanner.nextInt();
                if(choice==1){

                    System.out.println("Enter UserName: ");
                    userName=scanner.next();
                    System.out.println("Enter password");
                    password=scanner.next();
                    for(User user:users){
                        if(user.userVerify(userName,password))
                            loginSuccess=true;
                    }
                    if(loginSuccess){
                        int userOpt = 1;

                        for(Theatre t:theatres) {
                            t.displayBusInfo();
                        }

                        while(userOpt==1) {
                            System.out.println("Enter 1 to Book and 2 to exit");
                            userOpt = scanner.nextInt();
                            if(userOpt == 1) {
                                Booking booking = new Booking();
                                if(booking.isAvailable(bookings,theatres)) {
                                    bookings.add(booking);
                                    System.out.println("Your booking is confirmed");
                                }
                                else
                                    System.out.println("Sorry. Houseful. Try another Theatre or date.");
                            }
                            else{
                                loginSuccess=false;
                            }
                        }
                    }

                    else{
                        System.out.println("UserName/Password is invalid!! Try Again.");
                    }


                } else if (choice==2) {
                    System.out.println("Enter admin ID:");
                    userName=scanner.next();
                    System.out.println("Enter admin Password:");
                    password=scanner.next();
                    if(admin.verify(userName,password)){
                        while(true) {
                            System.out.println("1. Add a Theatre \n2. Add a movie \n3.exit");
                            choice = scanner.nextInt();
                            if (choice == 1) {
                                System.out.println("Enter Theatre Number: ");
                                theatreNumber = scanner.nextInt();
                                System.out.println("Enter Theatre Name: ");
                                theatreName = scanner.nextLine();
                                System.out.println("Capacity: ");
                                capacity = scanner.nextInt();
                                theatres.add(new Theatre(theatreNumber, theatreName, capacity));
                            } else if (choice == 2) {
                                System.out.println("Enter Theatre Number: ");
                                theatreNumber = scanner.nextInt();
                                System.out.println("Enter Movie Name: ");
                                movieName = scanner.next();

                                for (Theatre theatre : theatres) {
                                    if (theatre.getTheatreNumber() == theatreNumber) {
                                        theatre.addMovies(movieName);
                                    }
                                }
                            } else if(choice==3){
                                loginSuccess=false;
                                break;
                            }else{
                                System.out.println("Invalid Choice!!");
                            }
                        }
                    }
                }
            } else if (choice==2) {
                String confirmPassword;
                System.out.println("Enter emailID: ");
                emailID=scanner.next();
                System.out.println("Enter UserName: ");
                userName=scanner.next();
                System.out.println("Enter password:");
                password=scanner.next();
                System.out.println("Re-Enter password: ");
                confirmPassword=scanner.next();
                if(password.equals(confirmPassword)){
                    users.add(new User(emailID, userName, password));
                    System.out.println("Created Account Successfully");
                }
            }
        }

    }

}